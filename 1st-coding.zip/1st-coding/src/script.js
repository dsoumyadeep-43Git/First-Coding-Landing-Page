function handleContact() {
  alert('Thanks for your interest! You can reach me at: Dsoumyadeep43@gmail.com');
}

function handleProjects() {
  alert('My projects:\n1. This Landing Page\n2. Tip Calculator (coming soon!)\n3. Todo App (coming soon!)');
}